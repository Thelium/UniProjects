/**
 */
package simplepdl.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

import simplepdl.Guidance;
import simplepdl.Ressource;
import simplepdl.RessourceRequire;
import simplepdl.SimplepdlPackage;
import simplepdl.WorkDefinition;
import simplepdl.WorkSequence;

/**
 * This is the item provider adapter for a {@link simplepdl.Guidance} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GuidanceItemProvider extends ProcessElementItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GuidanceItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addElementPropertyDescriptor(object);
			addTextPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Element feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addElementPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Guidance_element_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Guidance_element_feature", "_UI_Guidance_type"),
				 SimplepdlPackage.Literals.GUIDANCE__ELEMENT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Text feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTextPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_Guidance_text_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_Guidance_text_feature", "_UI_Guidance_type"),
				 SimplepdlPackage.Literals.GUIDANCE__TEXT,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This returns Guidance.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Guidance"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	@Override
	public String getText(Object object) {
		Guidance guidance = ((Guidance) object);
		String text = guidance.getText();
		String wd_text = "[";
		if (guidance.getElement().size() > 0) {
			wd_text += ((WorkDefinition) guidance.getElement().get(0)).getName();
			for (int i = 1; guidance.getElement().size() > i; i++) {
				if (guidance.getClass() == WorkDefinition.class) {
					wd_text += "; " + "WD: " + ((WorkDefinition) guidance.getElement().get(i)).getName();						
				}
				if (guidance.getClass() == WorkSequence.class) {
					wd_text += "; " + "WS";				
				}
				if (guidance.getClass() == Guidance.class) {
					wd_text += "; " + "Guidance";	
				}
				if (guidance.getClass() == Ressource.class) {
					wd_text += "; " + ((Ressource) guidance.getElement().get(i)).getName();						
				}
				if (guidance.getClass() == RessourceRequire.class) {
					RessourceRequire rq = (RessourceRequire) guidance.getElement().get(i);
					wd_text += "; " + "RR: " + rq.getWorkdefinition().getName() + " <- " + rq.getQuantityRequire() + " - " + rq.getRessource().getName();
				}
				wd_text += "; " + ((WorkDefinition) guidance.getElement().get(i)).getName();
			}
		}
		wd_text += "]";
		
		return "GU: " + text + " | " + wd_text;
	}


	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Guidance.class)) {
		case SimplepdlPackage.GUIDANCE__ELEMENT:
		case SimplepdlPackage.GUIDANCE__TEXT:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}


	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
