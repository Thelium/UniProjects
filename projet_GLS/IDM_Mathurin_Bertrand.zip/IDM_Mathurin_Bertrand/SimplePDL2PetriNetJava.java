package simplepdl.manip;
import petrinet.*;
import petrinet.impl.*;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import simplepdl.Process;
import simplepdl.ProcessElement;
import simplepdl.Ressource;
import simplepdl.RessourceRequire;
import simplepdl.WorkDefinition;
import simplepdl.WorkSequence;
import simplepdl.WorkSequenceType;
import simplepdl.impl.*;
import simplepdl.SimplepdlFactory;
import simplepdl.SimplepdlPackage;



public class SimplePDL2PetriNetJava {

	public static void main(String[] args) {
		
		// Charger le package SimplePDL afin de l'enregistrer dans le registre d'Eclipse.
		SimplepdlPackage simplepdlInstance = SimplepdlPackage.eINSTANCE;
		PetrinetPackage petrinetInstance = PetrinetPackage.eINSTANCE;
		
		// Enregistrer l'extension ".xmi" comme devant Ãªtre ouverte Ã 
		// l'aide d'un objet "XMIResourceFactoryImpl"
		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		Map<String, Object> m = reg.getExtensionToFactoryMap();
		m.put("xmi", new XMIResourceFactoryImpl());
		
		// CrÃ©er un objet resourceSetImpl qui contiendra une ressource EMF (le modÃ¨le)
		ResourceSet resSetpdl = new ResourceSetImpl();
		ResourceSet resSetpetri = new ResourceSetImpl();

		// DÃ©finir la ressource (le modÃ¨le)
		URI modelURIpdl = URI.createURI("models/Ouvrier.xmi");
		Resource resourcePDL = resSetpdl.getResource(modelURIpdl,true);
		URI modelURIpetri = URI.createURI("models/PetrinetOuvrier.xmi");
		Resource resourcePetri = resSetpetri.createResource(modelURIpetri);
		
		
		// La fabrique pour fabriquer les Ã©lÃ©ments de SimplePDL
	    PetrinetFactory PetriFactory = PetrinetFactory.eINSTANCE;

		// Recup process
	    Process process = (Process) resourcePDL.getContents().get(0);
	    PetriNet petri = PetriFactory.createPetriNet();
	    petri.setName(process.getName());
	    
	    // Ajout modèle
	    resourcePetri.getContents().add(petri);
	    
	    // Base petrinet avec elements process
	    System.out.println(process.getProcessElements().size());
	    for (ProcessElement pe : process.getProcessElements()) {
	    	System.out.println(pe.getClass().toString());
	    	if (pe.getClass() == WorkDefinitionImpl.class) {
	    		WorkDefinition wd = (WorkDefinition) pe;
	    		// Creation et ajouts places	    		
	    		Place ready = PetriFactory.createPlace();
	    		Place started = PetriFactory.createPlace();
	    		Place running = PetriFactory.createPlace();
	    		Place finished = PetriFactory.createPlace();
	    		ready.setName(wd.getName() + "_ready");
	    		started.setName(wd.getName() + "_started");
	    		running.setName(wd.getName() + "_running");
	    		finished.setName(wd.getName() + "_finished");
	    		ready.setMarking(1);
	    		started.setMarking(0);
	    		running.setMarking(0);
	    		finished.setMarking(0);
	    		ready.setNet(petri);
	    		started.setNet(petri);
	    		running.setNet(petri);
	    		finished.setNet(petri);
	    		petri.getNode().add(ready);
	    		petri.getNode().add(started);
	    		petri.getNode().add(running);
	    		petri.getNode().add(finished);
	    		// Creation et ajout transitions
	    		Transition starts = PetriFactory.createTransition();
	    		Transition ends = PetriFactory.createTransition();
	    		starts.setName(wd.getName() + "_starts");
	    		ends.setName(wd.getName() + "_ends");
	    		starts.setNet(petri);
	    		ends.setNet(petri);
	    		petri.getNode().add(starts);
	    		petri.getNode().add(ends);
	    		// Creation et ajout arcs
	    		Arc r2s = PetriFactory.createArc();
	    		Arc s2s = PetriFactory.createArc();
	    		Arc s2r = PetriFactory.createArc();
	    		Arc r2e = PetriFactory.createArc();
	    		Arc e2f = PetriFactory.createArc();
	    		r2s.setKind(ArcKind.NORMAL);
	    		s2s.setKind(ArcKind.NORMAL);
	    		s2r.setKind(ArcKind.NORMAL);
	    		r2e.setKind(ArcKind.NORMAL);
	    		e2f.setKind(ArcKind.NORMAL);
	    		r2s.setSource(ready);
	    		r2s.setTarget(starts);
	    		s2s.setSource(starts);
	    		s2s.setTarget(started);
	    		s2r.setSource(starts);
	    		s2r.setTarget(running);
	    		r2e.setSource(running);
	    		r2e.setTarget(ends);
	    		e2f.setSource(ends);
	    		e2f.setTarget(finished);
	    		r2s.setPoids(1);
	    		s2s.setPoids(1);
	    		s2r.setPoids(1);
	    		r2e.setPoids(1);
	    		e2f.setPoids(1);
	    		r2s.setNet(petri);
	    		s2s.setNet(petri);
	    		s2r.setNet(petri);
	    		r2e.setNet(petri);
	    		e2f.setNet(petri);
	    		petri.getArc().add(r2s);
	    		petri.getArc().add(s2s);
	    		petri.getArc().add(s2r);
	    		petri.getArc().add(r2e);
	    		petri.getArc().add(e2f);	
	    	} else if (pe.getClass() == RessourceImpl.class) { //creation et ajout ressources
	    		Ressource re = (Ressource) pe;
	    		Place ressource = PetriFactory.createPlace();
	    		ressource.setName(re.getName());
	    		ressource.setMarking(re.getQuantity());
	    		ressource.setNet(petri);
	    		petri.getNode().add(ressource);
	    	}
	    }
	    // creation et ajout WorkSequences
	    for (ProcessElement pe : process.getProcessElements()) {
	    	if (pe.getClass() == WorkSequenceImpl.class) {
	    		WorkSequence ws = (WorkSequence) pe;
	    		Arc workseq = PetriFactory.createArc();
	    		workseq.setPoids(1);
	    		workseq.setKind(ArcKind.READ);
	    		workseq.setNet(petri);
	    		switch (ws.getLinkType().getValue()) {
	    		case WorkSequenceType.START_TO_START_VALUE | WorkSequenceType.START_TO_FINISH_VALUE :
	    			for (Node nd : petri.getNode()) {
	    				if (nd.getClass() == PlaceImpl.class) {
	    					Place p = (Place) nd;
	    					if (p.getName().equals(ws.getPredecessor().getName() + "_started")) {
	    						workseq.setSource(nd);
	    						break;
	    					}
	    				}
	    			}
	    		case WorkSequenceType.FINISH_TO_START_VALUE | WorkSequenceType.FINISH_TO_FINISH_VALUE :
	    			for (Node nd : petri.getNode()) {
	    				if (nd.getClass() == PlaceImpl.class) {
	    					Place p = (Place) nd;
	    					if (p.getName().equals(ws.getPredecessor().getName() + "_finished")) {
	    						workseq.setSource(nd);
	    						break;
	    					}
	    				}
	    			}
	    		}
	    		switch (ws.getLinkType().getValue()) {
	    		case WorkSequenceType.START_TO_START_VALUE | WorkSequenceType.FINISH_TO_START_VALUE :
	    			for (Node nd : petri.getNode()) {
	    				if (nd.getClass() == TransitionImpl.class) {
	    					Transition t = (Transition) nd;
	    					if (t.getName().equals(ws.getSuccessor().getName() + "_starts")) {
	    						workseq.setTarget(nd);
	    						break;
	    					}
	    				}
	    			}
	    		case WorkSequenceType.START_TO_FINISH_VALUE | WorkSequenceType.FINISH_TO_FINISH_VALUE :
	    			for (Node nd : petri.getNode()) {
	    				if (nd.getClass() == TransitionImpl.class) {
	    					Transition t = (Transition) nd;
	    					if (t.getName().equals(ws.getSuccessor().getName() + "_ends")) {
	    						workseq.setTarget(nd);
	    						break;
	    					}
	    				}
	    			}
	    		}
	    		petri.getArc().add(workseq);
	    	} else if (pe.getClass() == RessourceRequireImpl.class) { // creation et ajout RR
	    		RessourceRequire rr = (RessourceRequire) pe;
	    		Arc in = PetriFactory.createArc();
	    		Arc out = PetriFactory.createArc();
	    		for (Node nd : petri.getNode()) {
    				if (nd.getClass() == PlaceImpl.class) {
    					Place p = (Place) nd;
    					if (p.getName().equals(rr.getRessource().getName())) {
    						in.setSource(nd);
    						out.setTarget(nd);
    						break;
    					}
    				}
    			}
	    		for (Node nd : petri.getNode()) {
    				if (nd.getClass() == TransitionImpl.class) {
    					Transition t = (Transition) nd;
    					if (t.getName().equals(rr.getWorkdefinition().getName() + "_starts")) {
    						in.setTarget(nd);
    					} else if (t.getName().equals(rr.getWorkdefinition().getName() + "_ends")) {
    						out.setSource(nd);    					}
    				}
    			}
	    		in.setKind(ArcKind.NORMAL);
	    		out.setKind(ArcKind.NORMAL);
	    		in.setPoids(rr.getQuantityRequire());
	    		out.setPoids(rr.getQuantityRequire());
	    		in.setNet(petri);
	    		out.setNet(petri);
	    		petri.getArc().add(in);
	    		petri.getArc().add(out);
	    	}
	    	
	    }
	  

		// Sauver la ressource
	    try {
	    	resourcePetri.save(Collections.EMPTY_MAP);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
