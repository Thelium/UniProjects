% Projet Traitement du Signal
% NOMS et Pr�noms : BERTRAND Tom ; ZHENG Steven
% Groupe : 1SN-M


clc, clear all, close all
load donnees1.mat
load donnees2.mat

% 3.2 IMPLANTATION

% DONNEES
fp1=0;                  %fr�quence porteuse 1
fp2=46*1*10^3;          %fr�quence porteuse 2
T=40*1*10^(-3);         %dur�e d'un slot
Fe=120*1*10^3;          %Fr�quence d'�chantillonage
Te=1/Fe;                %P�riode d'�chantillonage
N = 101;                %ordre des filtres

% 3.2.1 Modulation bande basse
% 3.2.1     1   
Ns=floor((T/Te)/length(bits_utilisateur1));     %Nombre d'�chantillons du signal pour chque bit
Ts=(0:(Ns*length(bits_utilisateur2))-1).*Te;    %Echelle temporelle d'un slot
m1=(2*bits_utilisateur1)-1;                     %1er chaine de bits de -1 � 1
m2=(2*bits_utilisateur2)-1;                     %2e chaine de bits de -1 � 1

% Adaptation longueur signal
m1=kron(m1,ones(1,Ns));                         %Adaptation longueur message 1
m2=kron(m2,ones(1,Ns));                         %Adaptation longueur message 2

% 3.2.1     2 et 3

f1=linspace(-Fe/2,Fe/2,length(bits_utilisateur1)*Ns);                                %�chelle de fr�quences 1 centr�e en 0
f2=linspace(-Fe/2,Fe/2,length(bits_utilisateur2)*Ns);                                %�chelle de fr�quences 2 centr�e en 0
DSPm1=(1/length(m1))*abs(fftshift(fft(m1,Ns*length(bits_utilisateur1)))).^2;   %Distribution Spectrale de Puissance du message 1
DSPm2=(1/length(m2))*abs(fftshift(fft(m2,Ns*length(bits_utilisateur2)))).^2;   %DSP du message 2


subplot(4,1,1),plot(Ts,m1);                 %Trac� temporel du message 1
title('Trac� temporel m1');
xlabel('0 <= t <= T (en secondes)')
ylabel('Amplitude signal')
subplot(4,1,3),plot(Ts,m2,'r');             %Trac� temporel du message 2
title('Trac� temporel m2');
xlabel('0 <= t <= T (en secondes)')
ylabel('Amplitude signal')
subplot(4,1,2),plot(f1,DSPm1);             %Trac� Densit� Spectrale de Puissance du message 1
title('DSPm1');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude de Puissance')
subplot(4,1,4),plot(f2,DSPm2,'r');         %Trac� DSP du message 2
title('DSPm2');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude de Puissance')
% 3.2.2 Construction du signal MF-TDMA
% 3.2.2

Nb = T*Fe;                                  %Nombre de points par slot
Nslot = 5;                                  %Nombre de slots
Ttot=(0:(Nslot*Nb)-1).*Te;                  %Echelle de temps du signal complet (Nslot)

% 3.2.2     1 a
slot_vide = zeros(1,Nb);                                %Initialisation de la trame
NRZ_m1 = [slot_vide m1 slot_vide slot_vide slot_vide];  %Trame + message 1 (Trame1)
NRZ_m2 = [slot_vide slot_vide slot_vide slot_vide m2];  %Trame + message 2 (Trame2)
NRZ = NRZ_m2 + NRZ_m1;                                  %Trame1 + Trame2

figure
subplot(3,1,1),plot(Ttot,NRZ_m1);           %Trac� Trame1
title('Trac� Trame 1');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(3,1,2),plot(Ttot,NRZ_m2,'r');       %Trac� Trame2
title('Trac� Trame 2');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(3,1,3),plot(Ttot,NRZ,'g');          %Trac� Trame1 + Trame2
title('Trac� Trame 1 + Trame 2');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')


% 3.2.2     1 b

x1 = NRZ_m1.*cos(2*pi*fp1*Ttot);        %Modulation d'amplitude de la Trame1
x2 = NRZ_m2.*cos(2*pi*fp2*Ttot);        %Modulation d'amplitude de la Trame2

figure
subplot(2,1,1),plot(Ttot,x1)            %Trac� Trame1 modul�e
title('Trame 1 modul�e x1');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(2,1,2),plot(Ttot,x2,'r');       %Trac� Trame2 modul�e
title('Trame 2 modul�e x2');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')

% 3.2.2     2

x = x1 + x2;                                        %Somme des Trames modul�es
SNR = 100;                                          %Rapport signal sur bruit
Px = x*x'/length(x);                                %Puissance signal
Pb = Px/(10^(SNR/10));                              %Puissance bruit
bruit_gaussien_add=sqrt(Pb)*randn(1,length(x));     %Bruit gaussien additif
x_bga = x+bruit_gaussien_add ;                      %Signal complet modul� + bruit gaussien additif

% 3.2.2     3
DSP_bga = (1/length(x_bga))*abs(fftshift(fft(x_bga,length(x)))).^2;     %DSP du Signal modul� et bruit�

ftot= linspace (-Fe/2,Fe/2,length(x_bga));%Echelle de fr�quence Trame totale centr�e en 0
figure
subplot(2,1,1),plot(Ttot,x_bga);            %Trac� signal bruit� modul�
title('Signal bruit� modul�');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(2,1,2),plot(ftot,DSP_bga);          %Trac� DSP signal bruit� modul�
title('DSP du signal bruit� modul�');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude Puissance')

% 4 Mise en place du r�cepteur MF-TDMA

% 4.1 D�multiplexage des porteuses

% 4.1.1 Synth�se du filtre passe-bas
% 4.1.1     1 et 2


K = (-(N-1)/2:(N-1)/2);                 %Abscisses filtre
Fc = 23000; %(fp1+fp2)/2                %Fr�quence de coupure 
ff=linspace(-Fe/2,Fe/2,length(x));      %Echelle de fr�quence filtre centr�e en 0
fct = Fc/Fe;                            %Borne de l'intervalle des fr�quences pr�serv�es [-fct,fct]
hpb=2*fct*sinc(2*fct*K);                %R�ponse impulsionnelle filtre passe-bas
Hpb=abs(fftshift(fft(hpb,length(x))));  %R�ponse fr�quentielle filtre passe_bas
Hpbmax=max(DSP_bga)*Hpb;                %R�ponse impulsionnelle maximis�e 
                                        %(permet de le rendre visible quand superpos� avec DSP_bga

figure
subplot(3,1,1),plot(K,hpb);             %Trac� r�ponse impulsionnelle du filtre passe-bas
title('R�ponse impulsionnelle passe-bas');
xlabel('-(N-1)/2 <= t <= (N-1)/2 ')
ylabel('Amplitude signal')
subplot(3,1,2),plot(ff,Hpb);            %Trac� r�ponse fr�quentielle du filtre passe-bas
title('R�ponse fr�quentielle passe-bas');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude Puissance')
subplot(3,1,3),plot(ftot,DSP_bga);
hold on;
subplot(3,1,3),plot(ff,Hpbmax,'g');     %Superposition DSP_bga et Hpb
title('DSP signal bruit� + H passe-bas max');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude Puissance')
legend('DSP signal bruit�','passe-bas max')
%4.1.2 Synth�se du filtre passe-haut

% R�p impulsionnelle du filtre passe-haut (sans dirac)
hph = -hpb;

% Rajout d'un dirac de valeur 1 au milieu sur hph
hph(((N-1)/2)+1) = hph(((N-1)/2)+1) + 1;
Hph=abs(fftshift(fft(hph,length(x))));          %Transform�e de Fourier de la r�ponse impulsionnelle -> r�ponse fr�quentielle
Hphmax=max(DSP_bga)*Hph;                        %R�ponse impulsionnelle maximis�e 
                                                %(permet de le rendre visible quand superpos� avec DSP_bga

figure
subplot(3,1,1),plot(K,hph,'r');                 %Trac� de la r�ponse impulsionnelle du filtre passe_haut
title('r�p impulsionnelle passe-haut');
xlabel('-(N-1)/2 <= t <= (N-1)/2 ')
ylabel('Amplitude signal')
subplot(3,1,2),plot(ff,Hph,'r');                %Trac� de la r�ponse fr�quentielle du filtre passe-haut
title('r�p fr�quentielle passe-haut');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude Puissance')
subplot(3,1,3),plot(ftot,DSP_bga);              %Trac� DSP signal bruit� modul�
hold on;
subplot(3,1,3),plot(ff,Hphmax,'r');             %Trac� r�ponse impulsionnelle maximis�e
title('DSP signal bruit� + H passe-haut max');
xlabel('0 <= f <= Fe (en Hz)')
ylabel('Amplitude Puissance')
legend('DSP signal bruit�','passe-haut max')
x = [x zeros(1,(N-1)/2)];                       %Pr�-compensation du d�calage caus� par le filtrage
% 4.1.3 Filtrage
X1fret=filter(hpb,1,x);                         %Filtrage de X1 avec retard
X2fret=filter(hph,1,x);                         %Filtrage de X2 avec retard

% on retire le retard induit par le filtre
X1f=X1fret((N-1)/2+1:end) ;                     %Suppression du retard/d�calage pr�-compens� sur X1
X2f=X2fret((N-1)/2+1:end) ;                     %Suppression du retard/d�calage pr�-compens� sur X2

figure
subplot(2,1,1),plot(Ttot,X1f);                  %Trac� de X1 filtr�
title('signal x1 filtr�')
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(2,1,2),plot(Ttot,X2f,'r');              %Trac� de X2 filtr�
title('signal x2 filtr�');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')

% 4.2 Retour en bande de base

X1rbdb = X1f.*cos(2*pi*fp1*Ttot);               %Retour � la bande de base de X1
X2rbdb = X2f.*cos(2*pi*fp2*Ttot);               %Retour � la bande de base de X2

figure                                          %Affichage des signaux retourn�s � leur bande de base
subplot(2,1,1),plot(Ttot,X1rbdb);
title('Signal 1 retour bande de base')
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(2,1,2),plot(Ttot,X2rbdb,'r');
title('Signal 2 retour bande de base')
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')

X1rbdb = [X1rbdb zeros(1,(N-1)/2)];             %Pr�-compensation de X1 retourn� � la bande de base
X2rbdb = [X2rbdb zeros(1,(N-1)/2)];             %Pr�-compensation de X2 retourn� � la bande de base

X1rbdbfret = filter(hpb,1,X1rbdb);              %Filtrage de X1 retourn� dans la bande de base
X2rbdbfret = filter(hpb,1,X2rbdb);              %Filtrage de X2 retourn� dans la bande de base

X1rbdbf = X1rbdbfret((N-1)/2+1:end);            %Suppression du retard/d�calage pr�-compens� sur X1
X2rbdbf = X2rbdbfret((N-1)/2+1:end);            %Suppression du retard/d�calage pr�-compens� sur X2


figure
subplot(2,1,1),plot(Ttot,X1rbdbf);              %Trac� de X1 retourn� � la bande de base et filtr�
title('Signal 1 retour bande de base filtr�');
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')
subplot(2,1,2),plot(Ttot,X2rbdbf,'r');          %Trac� de X2 retourn� � la bande de base et filtr�
title('signal 2 retour bande de base filtr�')
xlabel('0 <= t <= 5T (en secondes)')
ylabel('Amplitude signal')

% 4.3 D�tection du slot utile
%Recherche des slots utiles par maximum de puissance
pslot1=zeros(1,Nslot);                                  %D�clarations de listes pour contenir les puissances de chaque slot
pslot2=zeros(1,Nslot);

for slot = 1:Nslot                                      %Recherche des slots utiles par maximum de puissance
    x1slot = X1rbdbf(((slot-1)*Nb)+1:slot*Nb);          %parcours des slots sur les signaux X1 et X2
    x2slot = X2rbdbf(((slot-1)*Nb)+1:slot*Nb);          
    x1pui = x1slot*x1slot';                             %calcul de puissance sur les slots
    x2pui = x2slot*x2slot';
    pslot1(slot) = x1pui;                               %enregistrement des puissances dans les listes
    pslot2(slot) = x2pui;
end

[~,slot_utile1] = max(pslot1);                          %Recherche de l'indice du slot � puissance maximale de chaque signal
[~,slot_utile2] = max(pslot2);

m1_r = X1rbdbf(((slot_utile1-1)*Nb)+1:slot_utile1*Nb);  %R�cup�ration du slot utile de chaque signal / signal reconstitu�
m2_r = X2rbdbf(((slot_utile2-1)*Nb)+1:slot_utile2*Nb);

figure
subplot(2,1,1),plot(Ts,m1_r);                           %Trac� des signaux utiles
title('Signal 1 reconstitu�')
xlabel('0 <= t <= T (en secondes)')
ylabel('Amplitude signal')
subplot(2,1,2),plot(Ts,m2_r);
title('Signal 2 reconstitu�')
xlabel('0 <= t <= T (en secondes)')
ylabel('Amplitude signal')

% 4.4 D�modulation bande de base

SignalFiltre1 = filter(ones(1,Ns),1,m1_r);              %Filtrage du signal utile
SignalEchantillone1= SignalFiltre1(Ns:Ns:end);          %R�cup�ration du signal �chantillon�
BitsRecuperes1 = (sign(SignalEchantillone1)+1)/2;       %Conversion en bits

SignalFiltre2 = filter(ones(1,Ns),1,m2_r);              %idem pour X2
SignalEchantillone2= SignalFiltre2(Ns:Ns:end);
BitsRecuperes2 = (sign(SignalEchantillone2)+1)/2;

figure                                                  %Affichage des suites de bits r�cup�r�es
subplot(2,1,1),plot(BitsRecuperes1);
title('Bits r�cup�r�s 1');
subplot(2,1,2),plot(BitsRecuperes2);
title('Bits r�cup�r�s 2');

Indice1 = bin2str(BitsRecuperes1)                       %Affichage des messages/indice d�cod�s
Indice2 = bin2str(BitsRecuperes2)

%Les indices sont 1 : ' Ma probabilit� d'apparition au semestre 5 est assez �lev�e '
%                 2 : ' Mes initiales, plac�es � l'envers, �voquent un vert support'
% Et m�nent � M. Jean-Yves Tourneret !