#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdbool.h>
#include "readcmd.h"
#include <errno.h>
#include <fcntl.h>
#define NBMAXPROC 50
#define READ 0
#define WRITE 1

/* enumeration des etats possibles d'un processus */
enum state {actif, suspendu};
typedef enum state state;

/* structure representant un processus */
typedef struct proc {
    int id;
    pid_t pid;
    state etat;
    char *lcmd;
} proc ;

/* VARIABLES GLOBALES
tableau des processus actifs, indice dans le tableau du dernier ajouté,
pid du processus en avant plan */
proc enCours[NBMAXPROC];
int indProc = 0;
pid_t pidCourant = -5; /* permet de différencier proc courant ou backgrounded, 
-5 qd pas de proc en avant plan */

/* ajout d'un processus à partir de ses caracteristiques */
void ajouterProc(int ident, int pid_, char *ligne){
    proc process;
    process.id = ident;
    process.pid = pid_;
    process.etat = actif;
    process.lcmd = malloc(sizeof(ligne));
    strcpy(process.lcmd, ligne);
    enCours[indProc] = process;
    indProc++;  
}

/* supprimer un processus de la liste des processus actifs à partir de son identifiant */
void supprimerProcPID(pid_t pidSuppr){pidCourant = -5;
    int i = 0;
    while(enCours[i].pid != pidSuppr && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
    } else {
        while(i < indProc){
            enCours[i] = enCours[i+1];
            i++;
        }
        indProc--;
    }
}

/* recherche du pid d'un processus à partir de son identifiant */
pid_t chercherPID(int identifiant){
    int i = 0;
    while(enCours[i].id != identifiant && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
    } else {
        return enCours[i].pid;
    }
    return -1;
}

/* recherche de l'identifiant d'un processus à partir de son pid */
int chercherID(pid_t pid){
    int i = 0;
    while(enCours[i].pid != pid && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
    } else {
        return enCours[i].id;
    }
    return -1;
}

/* interruption d'un processus actif */
void interrompreProc(int identifiant){
    int i = 0;
    while(enCours[i].id != identifiant && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
        printf("Identifiant inexistant\n");
    } else {
        kill(chercherPID(identifiant), SIGSTOP);
    }
}

/* passage de l'état d'un processus en suspendu dans la liste */
void statutInterrompu(int pid){
    int i = 0;
    while(enCours[i].pid != pid && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
    } else {
        enCours[i].etat = suspendu;
    }
}

/* reprise d'un processus en foreground ou background */
void reprendreProc(int identifiant, bool foreground){
    int i = 0;
    while(enCours[i].id != identifiant && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
        printf("Identifiant inexistant\n");
    } else {
        int pid = chercherPID(identifiant);
        if (foreground) {
            pidCourant = pid;
            int status;   
            kill(pid, SIGCONT);
            waitpid(pid, &status, WUNTRACED);
            pidCourant = -5;

            if(WIFEXITED(status) || WTERMSIG(status) == SIGKILL || WTERMSIG(status) == SIGTERM || 
            WTERMSIG(status) == SIGQUIT) {
                supprimerProcPID(pid);
            } else if(WIFSTOPPED(status)) {
                statutInterrompu(pid);
            }
        } else {
            kill(pid, SIGCONT);
        }
    }
}

/* passage de l'état d'un processus en actif dans la liste */
void statutActif(pid_t pid){
    int i = 0;
    while(enCours[i].pid != pid && i < indProc){
        i = i+1;
    }
    if(i >= indProc){
    } else {
        enCours[i].etat = actif;
    }
}

/* recherche du premier identifiant libre propre au minishell */
int idLibre(){
    int i=0;
    int j;
    bool b;
    if (indProc == 0) {
        return 0;
    }
    while(i<indProc){
        b = false;
        for(j=0; j<indProc; j++){
           if(enCours[j].id==i){
               b = true;
               break;
           }
        }
        if (b == true){
            i++;
        } else {
            return i;
        }
    }
    return indProc;
}

/* affichage des processus en cours */
void afficherProcessus(){
    int i;
    printf("Id : PID :    Etat :   Commande : \n");
    for (i = 0; i < indProc; i++){
        if (enCours[i].etat == actif){
            printf("%d    %d   %s %s \n", enCours[i].id, enCours[i].pid, "actif   ", enCours[i].lcmd);
        } else {
            printf("%d    %d   %s %s \n", enCours[i].id, enCours[i].pid, "suspendu", enCours[i].lcmd);
        }
    }
}

/* gestion de l'état du processus après un waitpid en fonction 
de la raison de l'envoie du signal SIGCHLD */
void gestion_etat(int pid, int etat_fils) {
    if (pid == 0){
    } else if (WIFSTOPPED(etat_fils)) {
        statutInterrompu(pid);
    } else if (WIFCONTINUED(etat_fils)) {
        statutActif(pid);
    } else if (WIFEXITED(etat_fils) || WTERMSIG(etat_fils) == SIGKILL || WTERMSIG(etat_fils) == SIGTERM || WTERMSIG(etat_fils) == SIGQUIT || WIFSIGNALED(etat_fils)) {
        supprimerProcPID(pid);
        free(enCours[indProc].lcmd);
    }
}

/* handler de SIGCHLD */
void background_handler(int sig) {
    int etat_fils;
    for(int i=0; i<indProc; i++) {
        int pid = (int) waitpid(enCours[i].pid, &etat_fils, WUNTRACED | WCONTINUED | WNOHANG);
        gestion_etat(pid, etat_fils);
    }
}

/* handler des signaux claviers */
void handler_sigclavier(int sig) {
    printf("\n");
    if(pidCourant != -5) {
        if(sig == SIGTSTP) {
            kill(pidCourant, SIGSTOP);
        } else if(sig == SIGINT) {
            kill(pidCourant, SIGTERM);
        }
    }
}


int main(int argc, char *argv[]) {

    //creation handler processus en background / foreground
    struct sigaction sigac;
    sigac.sa_handler = &background_handler;
    sigac.sa_flags = SA_RESTART;
    sigemptyset(&sigac.sa_mask);
    /* associe ce handler au signal SIGCHLD */
    sigaction(SIGCHLD, &sigac, NULL);

    //creation d'un handler pour les signaux claviers
    struct sigaction sig_clavier;
    sig_clavier.sa_handler = &handler_sigclavier;
    sig_clavier.sa_flags = SA_RESTART;
    sigemptyset(&sig_clavier.sa_mask);
    /* associe ce handler au signal SIGTSTP et SIGINT */
    sigaction(SIGTSTP, &sig_clavier, NULL);
    sigaction(SIGINT, &sig_clavier, NULL);

    struct cmdline *cmd; /* contient la commande saisie au clavier */
    pid_t pidFils ; /* pid pour reconnaitre le fils et le pere */
    int result;
    while(true){
        printf(">>>");
        cmd = readcmd(); /* structure de commande */
        if(cmd == NULL) {  /*ctrl + D utilise */
            printf("\n");
            break;
        }
        if((cmd->seq[0] == NULL)) {
            while(cmd->seq[0] == NULL) {
                printf(">>>");
                cmd = readcmd();
                if(cmd == NULL) { /* ctrl + D utilise */
                printf("\n");
                exit(0);
                }
            }
        }
        if(strcmp(cmd->seq[0][0], "exit") == 0) {
            break; /* on sort si exit est entre ou retour à la ligne sans rien d'autre*/
        } else if(strcmp(cmd->seq[0][0], "susp") == 0) {
            kill(getpid(), SIGSTOP);
        } else if(strcmp(cmd->seq[0][0], "cd") == 0){
            if(cmd->seq[0][1] == NULL) {
                chdir("/home");
            } else {
                chdir(cmd->seq[0][1]);
            }    
        } else if (strcmp(cmd->seq[0][0], "lj") == 0){
            afficherProcessus();
        } else if (strcmp(cmd->seq[0][0], "sj") == 0 && (cmd->seq[0][1] != NULL)){
            /* conversion char * en int */
            int idProc = strtol(cmd->seq[0][1], NULL, 10);
            interrompreProc(idProc);
        } else if (strcmp(cmd->seq[0][0], "bg") == 0 && (cmd->seq[0][1] != NULL)){
            /* conversion char * en int */
            int idProc = strtol(cmd->seq[0][1], NULL, 10);
            reprendreProc(idProc,false);
        } else if (strcmp(cmd->seq[0][0], "fg") == 0 && (cmd->seq[0][1] != NULL)){
            /* conversion char * en int */
            int idProc = strtol(cmd->seq[0][1], NULL, 10);
            reprendreProc(idProc,true);
        } else {
            pidFils = fork();
            if (pidFils == -1) {
                perror("fork\n"); /* si erreur dans le fork */
                exit(1);
            }
            if (pidFils == 0){
                /* masquage des signaux clavier pour les fils */
                sigset_t masque_fils;
                sigemptyset(&masque_fils);
                sigaddset(&masque_fils, SIGTSTP);
                sigaddset(&masque_fils, SIGINT);
                sigprocmask(SIG_BLOCK, &masque_fils, NULL);
                
                if((cmd->in != NULL) || (cmd->out != NULL)) {
                    if (cmd->in != NULL) {
                        int in = open(cmd->in, O_RDWR | O_CREAT , 0666);
                        if (in < 0) {
                            perror("Erreur ouverture IN ");
                            exit(1);
                        }
                        dup2(in, 0);
                        close(in);
                    }
                    if (cmd->out != NULL) {
                        int out = open(cmd->out, O_RDWR | O_CREAT | O_TRUNC, 0666);
                        if (out < 0) {
                            perror("Erreur ouverture OUT ");
                            exit(1);
                        }
                        dup2(out, 1);
                        close(out);
                    }
                    execlp(cmd->seq[0][0], cmd->seq[0][0], NULL);
                    perror("Erreur execution");
                    exit(1);

                } else if(cmd->seq[1] != NULL) {
                    int p[2];
                    pipe(p);
                    int pid2 = fork();
                    if(pid2 < 0) {
                        perror("erreur fork 2");
                        exit(1);
                    } else if(pid2 == 0) {
                        close(p[WRITE]);
                        dup2(p[READ], STDIN_FILENO);
                        close(p[READ]);
                        execvp(cmd->seq[1][0], cmd->seq[1]);
                    } else {
                        close(p[READ]);
                        dup2(p[WRITE], STDOUT_FILENO);
                        close(p[WRITE]);
                        execvp(cmd->seq[0][0], cmd->seq[0]);
                    }
                    
                

                } else {
                    execvp(cmd->seq[0][0],cmd->seq[0]); /* execution dans le fils */ 
                    perror("Erreur execution");
                    exit(1);
                }
         
            } else {
                if(cmd->backgrounded == NULL) {
                    pidCourant = pidFils;
                }
                
                /* ajout du processus aux processus en cours*/   
                int i = 0;
                int taille = 0;
                /* determination nombre de caractères */
                while (cmd->seq[0][i] != NULL){
                    taille = taille + strlen(cmd->seq[0][i]);
                    i++;
                }
                /* allocation memoire */
                taille = taille + i;
                char *ligne = malloc(taille);
                /* concatenation des arguments */
                strcpy(ligne, cmd->seq[0][0]);
                for (int j = 1; j < i; j++) {
                    strcat(ligne, " ");
                    strcat(ligne, cmd->seq[0][j]);
                }
                /* ajout du processus */
                int id_attribue = idLibre();
                ajouterProc(id_attribue, pidFils, ligne);
                printf("Identifiant attribué : %d\n",id_attribue);
                /* attente du fils si premier plan*/
                if(cmd->backgrounded == NULL) {
                    waitpid(pidFils,&result, WUNTRACED);
                    pidCourant = -5;
                    gestion_etat(pidFils, result);
                }
            }
        }
    }
}

